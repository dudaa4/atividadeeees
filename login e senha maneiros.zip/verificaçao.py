# ola professor
# pra fazer essa atividade eu segui um tutorial bem completinho no youtube
# sendo bem sincera, nao entendi nem metade das coisas que o moço digitou, mas pretendo reassistir 
# mais vezes pra entender melhor os comandos e tudo mais e quem sabe tentar depois refazer sozinha mesmo :D

def registro():
    db = open("database.txt", "r")
    username = input("Crie um user: ")
    senha = input("Crie uma senha: ")
    confirmacao = input("Confirme sua senha: ")
   
   
    d = []
    f = []
    for i in db:
        a,b = i.split(", ")
        b = b.strip()
        d.append(a)
        f.append(b)
    data = dict(zip(d, f)) 



    if senha != confirmacao:
        print("A senha está incorreta, tente novamente")
        registro()
    else:
        if len(senha)<=6:
            print("Senha muito curta, tente novamente: ")
            registro()
        elif username in d:
            print("User já existente")
            registro()
        else:
            db = open("database.txt", "a")
            db.write(username+", "+senha+"\n")
            print("Sucesso")

registro()

def acesso():
    db = open("database.txt", "r")
    username = input("Digite seu user: ")
    senha = input("Digite sua senha: ")

    if not len(username or senha)<1:
        d = []
        f = []
        for i in db:
            a,b = i.split(", ")
            b = b.strip()
            d.append(a)
            f.append(b)
        data = dict(zip(d, f))
        
        try: 
            if data[username]:
                try:
                    if senha == data[username]:
                        print("Login efetuado com sucesso!")
                        print("Bem-vindo,", username)
                    else:
                        print("User ou senha incorretos")
                except:
                    print("User ou senha incorretos")
            else:
                print("User ou senha não existem")
        except:
            print("User ou senha não existem")
    else:
        print("Por favor, digite algo")

def home(opcao=None):
    print("O que gostaria de fazer?")
    opcao = input("Login | Cadastro ")
    if opcao == "login":
        acesso()
    elif opcao == "cadastro":
        registro()
    else:
        print("Por favor, selecione uma opção")
home()





    
    
            





